// Author: Boris Hoeffgen <hoeffgen@uni-wuppertal.de>
//		   Dr. Werner Hofschuster <hofschuster@math.uni-wuppertal.de>
#include <iostream>
#include "interval.hpp"

using namespace std;
using namespace cxsc;